package com.cs4015.bookstore.api.core.book.models;

public enum Condition {
    LIKENEW,
    FINE,
    VERYGOOD,
    GOOD,
    FAIR,
    POOR
}
