package com.cs4015.bookstore.api.core.book.models;

public enum DigitalFormat {
    PDF,
    EPUB,
    MOBI
}
